import { BudgetCalculationResult, Period, CategoryId, MainCategoryId, BudgetCategory, BiblicalWisdom, CantineBreakdown, EnabledCategories, SelectedMeals, CustomCategory, CustomDateRange } from '../types';
import { BONDOUKOU_PRICES } from '../data/bondoukouData';

export function computeCantineBreakdown(
  cantineAmount: number,
  selectedMeals: SelectedMeals = { matin: true, midi: true, soir: true }
): CantineBreakdown {
  const isMatinActive = selectedMeals.matin;
  const isMidiActive = selectedMeals.midi;
  const isSoirActive = selectedMeals.soir;

  if (cantineAmount <= 0 || (!isMatinActive && !isMidiActive && !isSoirActive)) {
    return {
      matin: { label: 'Petit-Déjeuner (Matin)', ticketPrice: 100, souchePrice: 1000, souchesCount: 0, unitTicketsCount: 0, totalTicketsCount: 0, totalCost: 0, enabled: isMatinActive },
      midi: { label: 'Déjeuner (Midi)', ticketPrice: 200, souchePrice: 2000, souchesCount: 0, unitTicketsCount: 0, totalTicketsCount: 0, totalCost: 0, enabled: isMidiActive },
      soir: { label: 'Dîner (Soir)', ticketPrice: 200, souchePrice: 2000, souchesCount: 0, unitTicketsCount: 0, totalTicketsCount: 0, totalCost: 0, enabled: isSoirActive },
      totalSouches: 0,
      totalTickets: 0,
    };
  }

  // Relative weights: Matin (1), Midi (2), Soir (2)
  let weightMatin = isMatinActive ? 1 : 0;
  let weightMidi = isMidiActive ? 2 : 0;
  let weightSoir = isSoirActive ? 2 : 0;
  let totalWeight = weightMatin + weightMidi + weightSoir;

  let rawMatin = isMatinActive ? Math.round((cantineAmount * (weightMatin / totalWeight)) / 100) * 100 : 0;
  let rawMidi = isMidiActive ? Math.round((cantineAmount * (weightMidi / totalWeight)) / 100) * 100 : 0;
  let rawSoir = isSoirActive ? (cantineAmount - rawMatin - rawMidi) : 0;

  if (rawSoir < 0 && isSoirActive) {
    rawSoir = 0;
    if (isMidiActive) rawMidi = cantineAmount - rawMatin;
  }

  const matinSouches = isMatinActive ? Math.floor(rawMatin / 1000) : 0;
  const matinUnits = isMatinActive ? Math.floor((rawMatin % 1000) / 100) : 0;
  const matinTotalTickets = matinSouches * 10 + matinUnits;

  const midiSouches = isMidiActive ? Math.floor(rawMidi / 2000) : 0;
  const midiUnits = isMidiActive ? Math.floor((rawMidi % 2000) / 200) : 0;
  const midiTotalTickets = midiSouches * 10 + midiUnits;

  const soirSouches = isSoirActive ? Math.floor(rawSoir / 2000) : 0;
  const soirUnits = isSoirActive ? Math.floor((rawSoir % 2000) / 200) : 0;
  const soirTotalTickets = soirSouches * 10 + soirUnits;

  const totalSouches = matinSouches + midiSouches + soirSouches;
  const totalTickets = matinTotalTickets + midiTotalTickets + soirTotalTickets;

  return {
    matin: {
      label: 'Petit-Déjeuner (Matin)',
      ticketPrice: 100,
      souchePrice: 1000,
      souchesCount: matinSouches,
      unitTicketsCount: matinUnits,
      totalTicketsCount: matinTotalTickets,
      totalCost: rawMatin,
      enabled: isMatinActive,
    },
    midi: {
      label: 'Déjeuner (Midi)',
      ticketPrice: 200,
      souchePrice: 2000,
      souchesCount: midiSouches,
      unitTicketsCount: midiUnits,
      totalTicketsCount: midiTotalTickets,
      totalCost: rawMidi,
      enabled: isMidiActive,
    },
    soir: {
      label: 'Dîner (Soir)',
      ticketPrice: 200,
      souchePrice: 2000,
      souchesCount: soirSouches,
      unitTicketsCount: soirUnits,
      totalTicketsCount: soirTotalTickets,
      totalCost: rawSoir,
      enabled: isSoirActive,
    },
    totalSouches,
    totalTickets,
  };
}

export function calculateBudget(
  totalBudget: number,
  period: Period,
  customModifiers?: {
    cantineSouchesPerMonth?: number;
    foodDaily?: number;
    transportTripsPerMonth?: number;
    transportSchoolMonthly?: number;
    papotteMonthly?: number;
    customMonthlyCosts?: Record<string, number>;
  },
  priorityOrder: MainCategoryId[] = ['transport_school', 'cantine', 'food', 'transport', 'papotte'],
  enabledCategories: EnabledCategories = { transport_school: true, cantine: true, food: true, transport: true, papotte: true },
  selectedMeals: SelectedMeals = { matin: true, midi: true, soir: true },
  customCategories: CustomCategory[] = [],
  customDateRange?: CustomDateRange,
  isCiteUniversitaire: boolean = false
): BudgetCalculationResult {
  let monthsCount = 1;
  let daysCount = 30;
  let periodLabel = "Ce Mois (30 jours)";

  if (period === 'year') {
    monthsCount = BONDOUKOU_PRICES.ACADEMIC_YEAR_MONTHS; // 9
    daysCount = 270;
    periodLabel = "L'Année Académique 2026-2027 (9 mois)";
  } else if (period === 'custom' && customDateRange?.startDate && customDateRange?.endDate) {
    const start = new Date(customDateRange.startDate);
    const end = new Date(customDateRange.endDate);
    const diffMs = Math.max(0, end.getTime() - start.getTime());
    daysCount = Math.max(1, Math.round(diffMs / (1000 * 60 * 60 * 24)));
    monthsCount = Math.max(0.2, Math.round((daysCount / 30) * 10) / 10);

    const formatFr = (d: Date) => d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: 'numeric' });
    periodLabel = `Du ${formatFr(start)} au ${formatFr(end)} (${monthsCount.toString().replace('.', ',')} mois / ${daysCount} jours)`;
  }
  const monthlyBudget = totalBudget / monthsCount;

  // Round function to clean hundreds of FCFA in Côte d'Ivoire (e.g., 200F, 300F, 500F)
  const round100 = (val: number) => Math.round(val / 100) * 100;

  // 1. Mandatory Reserve for Imprévus & Épargne (10% of budget, min 500 FCFA)
  const minReservePercent = 0.10;
  const reserveMonthlyMandatory = Math.max(500, round100(monthlyBudget * minReservePercent));
  const allocatableMonthly = Math.max(0, monthlyBudget - reserveMonthlyMandatory);

  // Helper to check if category is enabled
  const isCatEnabled = (id: string) => {
    if (enabledCategories[id] !== undefined) return enabledCategories[id];
    const custom = customCategories.find((c) => c.id === id);
    return custom ? custom.enabled : true;
  };

  // All standard and custom category IDs
  const baseStandardIds = ['transport_school', 'cantine', 'food', 'transport', 'papotte'];
  const customCategoryIds = customCategories.map((c) => c.id);
  const allKnownIds = [...baseStandardIds, ...customCategoryIds];

  const fullPriorityOrder = [
    ...priorityOrder.filter((id) => allKnownIds.includes(id)),
    ...allKnownIds.filter((id) => !priorityOrder.includes(id)),
  ];

  // Active priorities according to enabledCategories
  const activePriorities = fullPriorityOrder.filter((id) => isCatEnabled(id));

  // Ideal target needs per month
  // If in Cite Universitaire, transport to school is 0 (walk on campus)!
  const targetNeeds: Record<string, number> = {
    transport_school: isCiteUniversitaire
      ? 0
      : (customModifiers?.transportSchoolMonthly !== undefined ? customModifiers.transportSchoolMonthly : 20000), // 500F A / 500F R = 1000F/j × 20 jours de cours
    transport: customModifiers?.transportTripsPerMonth ? customModifiers.transportTripsPerMonth * 1000 : 4000,
    cantine: customModifiers?.cantineSouchesPerMonth !== undefined ? customModifiers.cantineSouchesPerMonth * 2000 : 8000,
    food: customModifiers?.foodDaily !== undefined ? customModifiers.foodDaily * 30 : 27000, // ~900F/day
    papotte: customModifiers?.papotteMonthly !== undefined ? customModifiers.papotteMonthly : 5000,
  };

  customCategories.forEach((cc) => {
    let ccTarget = cc.monthlyCost;
    if ((!ccTarget || ccTarget === 0) && cc.unitPrice && cc.frequencyType) {
      const uPrice = cc.unitPrice;
      const fVal = cc.frequencyValue || 1;
      if (cc.frequencyType === 'school_days') ccTarget = uPrice * fVal * 20;
      else if (cc.frequencyType === 'daily') ccTarget = uPrice * fVal * 30;
      else if (cc.frequencyType === 'weekly') ccTarget = uPrice * fVal * 4;
      else if (cc.frequencyType === 'monthly') ccTarget = uPrice * fVal;
    }
    targetNeeds[cc.id] = customModifiers?.customMonthlyCosts?.[cc.id] ?? (ccTarget && ccTarget > 0 ? ccTarget : 5000);
  });

  const totalTargetNeeded = activePriorities.reduce((sum, id) => sum + (targetNeeds[id] || 0), 0);

  const allocatedMonthly: Record<string, number> = {
    transport_school: 0,
    transport: 0,
    cantine: 0,
    food: 0,
    papotte: 0,
  };
  customCategories.forEach((cc) => {
    allocatedMonthly[cc.id] = 0;
  });

  if (activePriorities.length > 0) {
    if (allocatableMonthly >= totalTargetNeeded) {
      // Generous budget: assign target needs to all enabled categories
      for (const id of activePriorities) {
        allocatedMonthly[id] = targetNeeds[id] || 0;
      }
    } else {
      // Budget is smaller than total target needed.
      let remainingToDistribute = allocatableMonthly;

      // If living off-campus (isCiteUniversitaire === false) and transport_school is active:
      // Transport École (500F A / 500F R = 1000F/j) is vital Priority #1 so student can attend class!
      if (!isCiteUniversitaire && isCatEnabled('transport_school')) {
        const schoolTarget = targetNeeds.transport_school || 20000;
        const schoolAllocated = round100(Math.min(schoolTarget, remainingToDistribute));
        allocatedMonthly['transport_school'] = schoolAllocated;
        remainingToDistribute -= schoolAllocated;
      }

      const otherActivePriorities = activePriorities.filter((id) => id !== 'transport_school' || isCiteUniversitaire);
      const defaultWeights = [0.40, 0.30, 0.20, 0.10];

      otherActivePriorities.forEach((id, index) => {
        if (remainingToDistribute <= 0) {
          allocatedMonthly[id] = 0;
          return;
        }
        const weight = defaultWeights[index] || (1 / (otherActivePriorities.length || 1));
        const target = targetNeeds[id] || 0;

        const calculatedShare = round100(allocatableMonthly * weight);
        const allocated = round100(Math.min(target, Math.min(remainingToDistribute, Math.max(200, calculatedShare))));
        
        allocatedMonthly[id] = allocated;
        remainingToDistribute -= allocated;
      });

      // If any leftover from rounding, assign to higher priority active categories that haven't hit target
      if (remainingToDistribute > 0) {
        for (const id of activePriorities) {
          if (remainingToDistribute <= 0) break;
          const current = allocatedMonthly[id] || 0;
          const target = targetNeeds[id] || 0;
          const add = Math.min(remainingToDistribute, target - current);
          if (add > 0) {
            const roundedAdd = round100(add);
            allocatedMonthly[id] += roundedAdd;
            remainingToDistribute -= roundedAdd;
          }
        }
      }
    }
  }

  // Monthly breakdown
  const transportSchoolMonthly = isCatEnabled('transport_school') ? (allocatedMonthly.transport_school || 0) : 0;
  const transportMonthly = isCatEnabled('transport') ? (allocatedMonthly.transport || 0) : 0;
  const cantineMonthly = isCatEnabled('cantine') ? (allocatedMonthly.cantine || 0) : 0;
  const foodMonthly = isCatEnabled('food') ? (allocatedMonthly.food || 0) : 0;
  const papotteMonthly = isCatEnabled('papotte') ? (allocatedMonthly.papotte || 0) : 0;

  // Daily food allocation rounded cleanly to hundreds of FCFA
  const foodDaily = foodMonthly > 0 ? round100(foodMonthly / 30) : 0;

  // Totals for selected period (monthly vs annual)
  const transportSchoolTotal = transportSchoolMonthly * monthsCount;
  const transportTotal = transportMonthly * monthsCount;
  const cantineTotal = cantineMonthly * monthsCount;
  const foodTotal = foodMonthly * monthsCount;
  const papotteTotal = papotteMonthly * monthsCount;

  let customAllocatedTotal = 0;
  customCategories.forEach((cc) => {
    if (isCatEnabled(cc.id)) {
      customAllocatedTotal += (allocatedMonthly[cc.id] || 0) * monthsCount;
    }
  });

  const allocatedTotal = transportSchoolTotal + transportTotal + cantineTotal + foodTotal + papotteTotal + customAllocatedTotal;
  const remainingTotal = totalBudget - allocatedTotal; // Guaranteed positive (includes Imprévus reserve)

  // Percentages relative to totalBudget
  const safeTotal = totalBudget > 0 ? totalBudget : 1;
  const transportSchoolPct = Math.round((transportSchoolTotal / safeTotal) * 100);
  const transportPct = Math.round((transportTotal / safeTotal) * 100);
  const cantinePct = Math.round((cantineTotal / safeTotal) * 100);
  const foodPct = Math.round((foodTotal / safeTotal) * 100);
  const papottePct = Math.round((papotteTotal / safeTotal) * 100);
  const customPctTotal = Math.round((customAllocatedTotal / safeTotal) * 100);
  const remainingPct = Math.max(0, 100 - (transportSchoolPct + transportPct + cantinePct + foodPct + papottePct + customPctTotal));

  // --- BUDGET LEVEL STATUS ---
  let status: 'insufficient' | 'tight' | 'balanced' | 'comfortable' = 'balanced';
  if (monthlyBudget < 20000) {
    status = 'insufficient'; // Budget très modeste
  } else if (monthlyBudget < 35000) {
    status = 'tight'; // Budget moyen
  } else if (monthlyBudget < 60000) {
    status = 'balanced'; // Équilibré
  } else {
    status = 'comfortable'; // Très confortable
  }

  // --- SPECIFIC BIBLICAL ADVICE FOR EACH CATEGORY ---
  
  // A0) Transport École Advice
  const transportSchoolVerse = "Proverbes 4:18 - « Le sentier des justes est comme la lumière resplendissante. »";
  const transportSchoolAdviceText = isCiteUniversitaire
    ? "Tu es logé sur le campus en cité universitaire : 0 FCFA de transport école ! Tu économises 20 000 FCFA/mois réaffectés à ta nourriture et tes études."
    : (isCatEnabled('transport_school')
      ? `${Math.round(transportSchoolMonthly).toLocaleString('fr-FR')} F / mois pour tes cours du Lundi au Vendredi (500F Aller / 500F Retour = 1000F/jour). Habitant hors cité, ce trajet est ta priorité N°1 !`
      : "Transport école désactivé dans cette simulation.");

  // A) Transport Religieux Advice
  const transportVerse = "Actes 2:46 - « Ils étaient chaque jour tous ensemble assidus au temple. »";
  const transportAdviceText = enabledCategories.transport
    ? `${Math.round(transportMonthly / monthsCount)} F / mois alloués pour le transport église/mosquée. Si c'est serré, vas-y à pied. Dieu regarde ton cœur, pas ton moyen de transport.`
    : "Transport désactivé. Déplace-toi à pied vers le temple ou l'université.";

  // B) Cantine Advice
  let cantineVerse = "Jean 6:12 - « Ramassez les morceaux qui restent, afin que rien ne soit perdu. »";
  let cantineAdviceText = enabledCategories.cantine
    ? `${Math.round(cantineMonthly).toLocaleString('fr-FR')} F / mois attribués au CROU-B. Tickets matin à 100F (souche 1000F), midi & soir à 200F (souche 2000F). Achète en souches pour sécuriser tes repas !`
    : "Cantine désactivée dans cette simulation.";

  // C) Food Advice
  let foodVerse = "Proverbes 30:8 - « Donne-moi le pain qui m'est nécessaire. »";
  let foodAdviceText = enabledCategories.food
    ? `${foodDaily} F / jour pour la vie étudiante. À côté de la cantine CROU-B, fais-toi plaisir de temps en temps (Garba, maquis, petites friandises).`
    : "Nourriture de vie étudiante désactivée.";

  // D) Papotte Advice
  let papotteVerse = "Ecclésiaste 9:8 - « Que tes vêtements soient blancs en tout temps. »";
  let papotteAdviceText = enabledCategories.papotte
    ? `${Math.round(papotteMonthly).toLocaleString('fr-FR')} F / mois réservés pour le pack hygiène (savon, dentifrice, parfum). Un corps propre honore Dieu.`
    : "Pack hygiène désactivé.";

  // E) Global Wisdom based on RESTE
  const globalRef = "Luc 14:28";
  const globalVerse = "« Calcule la dépense. »";
  const globalAdvice = `Parfait ! Ton budget de ${totalBudget.toLocaleString('fr-FR')} FCFA est totalement équilibré sans aucun déficit. Une réserve obligatoire de ${Math.round(remainingTotal).toLocaleString('fr-FR')} FCFA (${remainingPct}%) est gardée pour tes imprévus et ton épargne.`;

  const globalWisdom: BiblicalWisdom = {
    reference: globalRef,
    verseText: globalVerse,
    spiritualAdvice: globalAdvice,
    antiWasteTip: "Ta réserve d'imprévus est automatiquement sécurisée. Ne la dépense que pour les urgences médicales ou scolaires.",
    encouragement: "Que Dieu bénisse tes finances et tes études à l'Université de Bondoukou !",
    theme: "Sagesse, Réserve & Prévoyance",
  };

  const getRank = (catId: string) => {
    const activeIdx = activePriorities.indexOf(catId);
    if (activeIdx !== -1) {
      return activeIdx + 1;
    }
    const allIdx = fullPriorityOrder.indexOf(catId);
    if (allIdx !== -1) {
      return activePriorities.length + allIdx + 1;
    }
    return activePriorities.length + 1;
  };

  function makeShortfallInfo(
    catName: string,
    allocatedMonthly: number,
    targetMonthly: number,
    totalBudgetVal: number,
    unitStartingPrice?: number
  ): { targetAmount: number; startingPrice?: number; isShortfall: boolean; shortfallExplanation?: string } {
    const isShortfall = allocatedMonthly < targetMonthly && targetMonthly > 0;
    if (!isShortfall) {
      return { targetAmount: targetMonthly, startingPrice: unitStartingPrice, isShortfall: false };
    }

    const gap = targetMonthly - allocatedMonthly;
    const priceNotice = unitStartingPrice && unitStartingPrice > 0
      ? `Tu as spécifié un prix de départ de ${targetMonthly.toLocaleString('fr-FR')} FCFA (prix unitaire : ${unitStartingPrice.toLocaleString('fr-FR')} FCFA) pour "${catName}".`
      : `Le montant cible / coût prévu pour "${catName}" est de ${targetMonthly.toLocaleString('fr-FR')} FCFA / mois.`;

    const explanation = `🤖 EXPLICATION DE L'IA STADJAI :

Mon cher étudiant, voici l'explication de l'IA STADJAI pour la catégorie "${catName}" :

${priceNotice}
En appliquant ton classement de priorités, l'IA STADJAI a alloué ${allocatedMonthly.toLocaleString('fr-FR')} FCFA / mois (soit un écart de -${gap.toLocaleString('fr-FR')} FCFA par rapport au montant cible).

💡 Raison du calcul par L'IA STADJAI :
Sur ton budget total de ${totalBudgetVal.toLocaleString('fr-FR')} FCFA, l'IA STADJAI a accordé la priorité absolue aux besoins vitaux prioritaires (Nourriture CROU-B & Transport École) pour te protéger de toute disette et sécuriser ta réserve d'urgence.

💡 Conseil pratique de L'IA STADJAI :
Pour cumuler la somme totale de ${targetMonthly.toLocaleString('fr-FR')} FCFA, garde de côté cette enveloppe de ${allocatedMonthly.toLocaleString('fr-FR')} FCFA sur 2 à 3 mois !`;

    return {
      targetAmount: targetMonthly,
      startingPrice: unitStartingPrice,
      isShortfall: true,
      shortfallExplanation: explanation,
    };
  }

  const transportSchoolShortfall = makeShortfallInfo('Transport École (Lundi-Vendredi)', transportSchoolMonthly, targetNeeds.transport_school || 20000, totalBudget, 1000);
  const transportShortfall = makeShortfallInfo('Transport Religieux', transportMonthly, targetNeeds.transport || 4000, totalBudget);
  const cantineShortfall = makeShortfallInfo('Cantine CROU-B', cantineMonthly, targetNeeds.cantine || 8000, totalBudget);
  const foodShortfall = makeShortfallInfo('Nourriture Vie Étudiante', foodMonthly, targetNeeds.food || 27000, totalBudget);
  const papotteShortfall = makeShortfallInfo('Papotte (Hygiène)', papotteMonthly, targetNeeds.papotte || 5000, totalBudget);

  const categories: Record<CategoryId, BudgetCategory> = {
    transport_school: {
      id: 'transport_school',
      priorityOrder: getRank('transport_school'),
      emoji: '🚌',
      name: isCiteUniversitaire ? 'TRANSPORT ÉCOLE (CITÉ UNIVERSITAIRE)' : 'TRANSPORT ÉCOLE (LUNDI AU VENDREDI)',
      subtitle: isCiteUniversitaire ? 'Logé sur campus : 0 FCFA (Trajet à pied)' : '500F Aller / 500F Retour (1 000F / jour de cours)',
      description: isCiteUniversitaire
        ? 'En cité universitaire, tu résides directement sur le campus : 0 FCFA de transport pour aller aux cours.'
        : 'Transport quotidien obligatoire pour aller aux cours du Lundi au Vendredi (500 FCFA Aller + 500 FCFA Retour).',
      amount: transportSchoolTotal,
      percentage: transportSchoolPct,
      color: 'bg-cyan-600 text-cyan-100 border-cyan-500',
      badgeText: isCiteUniversitaire
        ? '0 FCFA (Sur campus)'
        : (period === 'year' ? `${transportSchoolTotal.toLocaleString('fr-FR')} F / an` : `${transportSchoolMonthly.toLocaleString('fr-FR')} F / mois`),
      unitInfo: isCiteUniversitaire
        ? 'Logé en Cité Universitaire (0 FCFA de transport)'
        : '500F Aller + 500F Retour = 1000F / jour de cours (~20 jours / mois)',
      detailsText: isCiteUniversitaire
        ? '0 FCFA (Tu résides sur le campus universitaire)'
        : (period === 'year' ? `${Math.round(transportSchoolMonthly)} FCFA × 9 mois = ${transportSchoolTotal.toLocaleString('fr-FR')} FCFA` : `${transportSchoolMonthly.toLocaleString('fr-FR')} FCFA / mois (500F A / 500F R)`),
      isEssential: true,
      biblicalVerse: transportSchoolVerse,
      biblicalAdvice: transportSchoolAdviceText,
      enabled: isCatEnabled('transport_school'),
      ...transportSchoolShortfall,
    },
    transport: {
      id: 'transport',
      priorityOrder: getRank('transport'),
      emoji: '🕌',
      name: 'TRANSPORT RELIGIEUX',
      subtitle: 'Église / Mosquée (1 fois par semaine)',
      description: 'Déplacement aller-retour église/mosquée.',
      amount: transportTotal,
      percentage: transportPct,
      color: 'bg-blue-600 text-blue-100 border-blue-500',
      badgeText: period === 'year' ? `${transportTotal.toLocaleString('fr-FR')} F / an` : `${transportMonthly.toLocaleString('fr-FR')} F / mois`,
      unitInfo: `${Math.round(transportMonthly / 1000)} visites / mois (~1000F / sortie)`,
      detailsText: period === 'year' ? `${Math.round(transportMonthly)} FCFA × 9 mois = ${transportTotal.toLocaleString('fr-FR')} FCFA` : `${transportMonthly.toLocaleString('fr-FR')} FCFA / mois`,
      isEssential: true,
      biblicalVerse: transportVerse,
      biblicalAdvice: transportAdviceText,
      enabled: enabledCategories.transport,
      ...transportShortfall,
    },
    cantine: {
      id: 'cantine',
      priorityOrder: getRank('cantine'),
      emoji: '🍛',
      name: 'CANTINE (CROU-B)',
      subtitle: 'Restaurant Universitaire',
      description: 'Matin : Ticket 100F (souche 1000F) | Midi & Soir : Ticket 200F (souche 2000F).',
      amount: cantineTotal,
      percentage: cantinePct,
      color: 'bg-emerald-600 text-emerald-100 border-emerald-500',
      badgeText: `${Math.round(cantineMonthly).toLocaleString('fr-FR')} F / mois`,
      unitInfo: 'Matin: 100F (souche 1000F) | Midi/Soir: 200F (souche 2000F)',
      detailsText: `Matin (100F/tks) + Déjeuner/Dîner (200F/tks) = ${cantineTotal.toLocaleString('fr-FR')} FCFA`,
      isEssential: true,
      biblicalVerse: cantineVerse,
      biblicalAdvice: cantineAdviceText,
      cantineBreakdown: computeCantineBreakdown(cantineTotal, selectedMeals),
      enabled: enabledCategories.cantine,
      ...cantineShortfall,
    },
    food: {
      id: 'food',
      priorityOrder: getRank('food'),
      emoji: '🥐',
      name: 'NOURRITURE VIE ÉTUDIANTE',
      subtitle: 'Plaisir de temps en temps (Garba, maquis, friandises)',
      description: 'À côté de la cantine CROU-B, budget pour se faire plaisir de temps en temps (Garba, maquis, boulangerie, friandises).',
      amount: foodTotal,
      percentage: foodPct,
      color: 'bg-amber-600 text-amber-100 border-amber-500',
      badgeText: `${foodDaily.toLocaleString('fr-FR')} F / jour`,
      unitInfo: `Extra plaisir : ~${foodDaily} F / jour`,
      detailsText: `${foodDaily} FCFA / jour × ${daysCount} jours = ${foodTotal.toLocaleString('fr-FR')} FCFA`,
      isEssential: true,
      biblicalVerse: foodVerse,
      biblicalAdvice: foodAdviceText,
      enabled: enabledCategories.food,
      ...foodShortfall,
    },
    papotte: {
      id: 'papotte',
      priorityOrder: getRank('papotte'),
      emoji: '🧼',
      name: 'PAPOTTE',
      subtitle: 'Savon + Savon liquide + Pâte + Parfum',
      description: 'Pack hygiène indispensable.',
      amount: papotteTotal,
      percentage: papottePct,
      color: 'bg-purple-600 text-purple-100 border-purple-500',
      badgeText: `${Math.round(papotteMonthly).toLocaleString('fr-FR')} F / mois`,
      unitInfo: 'Hygiène mensuelle',
      detailsText: `${Math.round(papotteMonthly).toLocaleString('fr-FR')} FCFA / mois × ${monthsCount} mois = ${papotteTotal.toLocaleString('fr-FR')} FCFA`,
      isEssential: true,
      biblicalVerse: papotteVerse,
      biblicalAdvice: papotteAdviceText,
      enabled: isCatEnabled('papotte'),
      ...papotteShortfall,
    },
    reserve: {
      id: 'reserve',
      priorityOrder: 99,
      emoji: '💰',
      name: 'Imprévus & Épargne (Sécurité)',
      subtitle: 'Gardé de côté pour les urgences',
      description: 'Réserve de sécurité financière garantie.',
      amount: remainingTotal,
      percentage: remainingPct,
      color: 'bg-teal-600 text-teal-100 border-teal-500',
      badgeText: `${remainingTotal.toLocaleString('fr-FR')} F`,
      unitInfo: `${remainingPct}% du budget total gardé en sécurité`,
      detailsText: `Imprévus & Épargne réservés : ${remainingTotal.toLocaleString('fr-FR')} FCFA`,
      isEssential: false,
      enabled: true,
    },
  };

function generateCustomCategoryInsights(
  cc: CustomCategory,
  ccMonthly: number,
  monthsCount: number
): {
  subtitle: string;
  unitInfo: string;
  detailsText: string;
  biblicalVerse: string;
  biblicalAdvice: string;
} {
  const text = `${cc.name} ${cc.description || ''}`.toLowerCase();
  const descText = cc.description ? cc.description.trim() : '';

  let subtitle = descText ? `Détail : ${descText}` : 'Catégorie Personnalisée';
  let unitInfo = descText ? `Objectif : ${descText}` : `Budget alloué : ${Math.round(ccMonthly).toLocaleString('fr-FR')} FCFA / mois`;
  let detailsText = `${Math.round(ccMonthly).toLocaleString('fr-FR')} FCFA / mois × ${monthsCount} mois = ${(ccMonthly * monthsCount).toLocaleString('fr-FR')} FCFA`;

  if (cc.unitPrice && cc.unitPrice > 0 && cc.frequencyType) {
    const uP = cc.unitPrice.toLocaleString('fr-FR');
    const fV = cc.frequencyValue || 1;
    if (cc.frequencyType === 'school_days') {
      unitInfo = `${uP} FCFA / jour de cours (~20 jours / mois)`;
      detailsText = `${uP} F × 20 jours de cours = ${Math.round(ccMonthly).toLocaleString('fr-FR')} FCFA / mois (soit ${(ccMonthly * monthsCount).toLocaleString('fr-FR')} F sur la période)`;
    } else if (cc.frequencyType === 'daily') {
      unitInfo = `${uP} FCFA / jour (7j / 7, ~30 jours / mois)`;
      detailsText = `${uP} F × 30 jours = ${Math.round(ccMonthly).toLocaleString('fr-FR')} FCFA / mois (soit ${(ccMonthly * monthsCount).toLocaleString('fr-FR')} F sur la période)`;
    } else if (cc.frequencyType === 'weekly') {
      unitInfo = `${uP} FCFA × ${fV} fois / semaine (~4 semaines / mois)`;
      detailsText = `${uP} F × ${fV} fois/semaine × 4 semaines = ${Math.round(ccMonthly).toLocaleString('fr-FR')} FCFA / mois`;
    } else if (cc.frequencyType === 'monthly') {
      unitInfo = `${uP} FCFA × ${fV} fois / mois`;
      detailsText = `${uP} F × ${fV} fois/mois = ${Math.round(ccMonthly).toLocaleString('fr-FR')} FCFA / mois`;
    }
  }
  let biblicalVerse = 'Proverbes 16:3 - « Recommande à l\'Éternel tes œuvres, et tes projets réussiront. »';
  let biblicalAdvice = descText
    ? `Pour ton besoin "${descText}" : gère cette enveloppe de ${Math.round(ccMonthly).toLocaleString('fr-FR')} F/mois avec méthode et sérénité.`
    : `Sois économe et veille à ne pas dépasser cette enveloppe de ${Math.round(ccMonthly).toLocaleString('fr-FR')} F/mois pour conserver ton équilibre.`;

  if (text.includes('internet') || text.includes('data') || text.includes('forfait') || text.includes('réseau') || text.includes('wifi') || text.includes('pass')) {
    subtitle = descText ? `Communication : ${descText}` : 'Internet & Recherches Académiques';
    unitInfo = `${Math.round(ccMonthly).toLocaleString('fr-FR')} F / mois (Connexion & WhatsApp)`;
    biblicalVerse = 'Proverbes 18:15 - « Un cœur intelligent acquiert la science. »';
    biblicalAdvice = 'Utilise ton forfait en priorité pour tes recherches universitaires et les communications indispensables. Évite de consommer toute ta data sur des contenus distrayants.';
  } else if (text.includes('loyer') || text.includes('maison') || text.includes('studio') || text.includes('chambre') || text.includes('logement')) {
    subtitle = descText ? `Hébergement : ${descText}` : 'Loyer & Habitation Étudiante';
    unitInfo = 'Loyer & charges mensuelles du logement';
    biblicalVerse = 'Esaïe 32:18 - « Mon peuple demeurera dans des habitations sûres. »';
    biblicalAdvice = 'Règle ton loyer en priorité dès réception de ton budget. Un toit sûr et calme est le garant de tes révisions studieuses à Bondoukou.';
  } else if (text.includes('santé') || text.includes('pharmacie') || text.includes('médicament') || text.includes('soin') || text.includes('docteur') || text.includes('clinique')) {
    subtitle = descText ? `Santé : ${descText}` : 'Soin & Pharmacie de première nécessité';
    unitInfo = 'Couverture santé & médicaments de secours';
    biblicalVerse = '3 Jean 1:2 - « Je souhaite que tu sois en bonne santé. »';
    biblicalAdvice = 'Ta santé est primordiale pour réussir ton année universitaire. Conserve cette somme au chaud pour réagir vite en cas de fièvre ou de fatigue.';
  } else if (text.includes('livre') || text.includes('polycope') || text.includes('fourniture') || text.includes('cahier') || text.includes('fiche') || text.includes('étude') || text.includes('copie')) {
    subtitle = descText ? `Édition : ${descText}` : 'Polycopiés & Matériel d\'Études';
    unitInfo = 'Supports de cours & fournitures de classe';
    biblicalVerse = 'Proverbes 4:7 - « Avec tout ce que tu possèdes, acquiers l\'intelligence. »';
    biblicalAdvice = 'Investis dans les polycopiés et fiches recommandés par tes enseignants. Organise le prêt de livres avec tes camarades de promo.';
  } else if (text.includes('vêtement') || text.includes('habit') || text.includes('chaussure') || text.includes('tenue') || text.includes('style')) {
    subtitle = descText ? `Style : ${descText}` : 'Achats Vestimentaires & Entretien';
    unitInfo = 'Garde-robe & habits propres';
    biblicalVerse = 'Ecclésiaste 9:8 - « Que tes vêtements soient blancs en tout temps. »';
    biblicalAdvice = 'Maintiens une tenue décente et soignée à l\'université, tout en évitant de dépenser l\'argent vital dans les modes passagères.';
  } else if (text.includes('électricité') || text.includes('eau') || text.includes('gaz') || text.includes('charge') || text.includes('facture')) {
    subtitle = descText ? `Charges : ${descText}` : 'Factures de Ménage (Électricité/Eau/Gaz)';
    unitInfo = 'Règlement des factures mensuelles';
    biblicalVerse = 'Luc 16:10 - « Celui qui est fidèle dans les petites choses l\'est aussi dans les grandes. »';
    biblicalAdvice = 'Fais attention aux fuites d\'eau et éteins les lumières en quittant ta chambre pour maîtriser tes charges mensuelles.';
  } else if (text.includes('dîme') || text.includes('offrande') || text.includes('don') || text.includes('église') || text.includes('mosquée') || text.includes('générosité')) {
    subtitle = descText ? `Foi : ${descText}` : 'Générosité & Actes de Foi';
    unitInfo = 'Contribution spirituelle & solidarité';
    biblicalVerse = 'Proverbes 3:9 - « Honore l\'Éternel avec tes biens et avec les prémices de ton revenu. »';
    biblicalAdvice = 'Donner avec joie et fidélité apporte la paix du cœur et développe la sagesse dans la gestion du reste de tes finances.';
  } else if (text.includes('sport') || text.includes('loisir') || text.includes('détente') || text.includes('sortie') || text.includes('passion')) {
    subtitle = descText ? `Loisir : ${descText}` : 'Détente & Activités Récréatives';
    unitInfo = 'Activités physiques & pause bien méritée';
    biblicalVerse = '1 Timothée 4:8 - « L\'exercice corporel est utile, la piété l\'est à tout. »';
    biblicalAdvice = 'Le sport et les pauses régénèrent l\'esprit après les amphis. Veille à ne pas dépasser cette allocation de loisir.';
  }

  return {
    subtitle,
    unitInfo,
    detailsText,
    biblicalVerse,
    biblicalAdvice,
  };
}

  // Add Custom Categories dynamically
  customCategories.forEach((cc) => {
    const ccMonthly = isCatEnabled(cc.id) ? (allocatedMonthly[cc.id] || 0) : 0;
    const ccTotal = ccMonthly * monthsCount;
    const ccPct = Math.round((ccTotal / safeTotal) * 100);

    const targetMonthly = targetNeeds[cc.id] || cc.monthlyCost || 5000;
    const customShortfall = makeShortfallInfo(cc.name, ccMonthly, targetMonthly, totalBudget, cc.unitPrice);

    const insights = generateCustomCategoryInsights(cc, ccMonthly, monthsCount);

    categories[cc.id] = {
      id: cc.id,
      priorityOrder: getRank(cc.id),
      emoji: cc.emoji || '📌',
      name: cc.name.toUpperCase(),
      subtitle: insights.subtitle,
      description: cc.description || `Budget personnel pour ${cc.name}.`,
      amount: ccTotal,
      percentage: ccPct,
      color: 'bg-indigo-600 text-indigo-100 border-indigo-500',
      badgeText: `${Math.round(ccMonthly).toLocaleString('fr-FR')} F / mois`,
      unitInfo: insights.unitInfo,
      detailsText: insights.detailsText,
      isEssential: false,
      biblicalVerse: insights.biblicalVerse,
      biblicalAdvice: insights.biblicalAdvice,
      enabled: isCatEnabled(cc.id),
      ...customShortfall,
    };
  });

  return {
    totalBudget,
    period,
    monthsCount,
    daysCount,
    periodLabel,
    customDateRange,
    isCiteUniversitaire,
    allocatedTotal,
    remainingAmount: remainingTotal,
    categories,
    status,
    wisdom: globalWisdom,
    enabledCategories,
    selectedMeals,
  };
}
