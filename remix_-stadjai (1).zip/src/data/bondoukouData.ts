import { BiblicalWisdom } from '../types';

export const BONDOUKOU_PRICES = {
  CANTINE_PETIT_DEJEUNER_TICKET: 100, // 100 FCFA per ticket (matin)
  CANTINE_PETIT_DEJEUNER_SOUCHE: 1000, // Souche de 10 tickets matin = 1000 FCFA
  CANTINE_MIDI_SOIR_TICKET: 200, // 200 FCFA per ticket (midi & soir)
  CANTINE_MIDI_SOIR_SOUCHE: 2000, // Souche de 10 tickets midi/soir = 2000 FCFA
  CANTINE_TICKETS_PER_SOUCHE: 10,
  
  TRANSPORT_SCHOOL_DAILY_ROUNDTRIP: 1000, // 500 FCFA aller + 500 FCFA retour = 1000 FCFA / jour de cours (Lundi au Vendredi)
  TRANSPORT_CHURCH_MOSQUE_ROUNDTRIP: 1000, // 1000 FCFA aller-retour inclus
  
  PAPOTTE_MIN_MONTHLY: 2000, // Pack hygiène (savon, savon liquide, pâte, parfum)
  
  FOOD_LIFE_MIN_DAILY: 500, // 500 FCFA à plus par jour (plaisir de temps en temps)
  
  ACADEMIC_YEAR_MONTHS: 9, // "L'année c'est 9 mois"
};

export const BIBLICAL_WISDOM_DATABASE: BiblicalWisdom[] = [
  {
    reference: "Proverbes 21:20",
    verseText: "« Il y a de précieux trésors et de l'huile dans la demeure du sage; mais l'homme insensé les engloutit. »",
    spiritualAdvice: "Un bon étudiant administre avec sagesse les petites sommes que Dieu lui confie. Ne dépense pas tout ton argent dès réception de ton allocation ou de l'aide familiale. Garde toujours une réserve stratégique pour le lendemain.",
    antiWasteTip: "Achète tes tickets de cantine en souche de 10 (2 000 F) pour sécuriser tes repas du mois avant de dépenser dans les snacks de boulangerie.",
    encouragement: "Sois le sage de ta cité universitaire à Bondoukou. En maîtrisant tes dépenses aujourd'hui, tu prépares ta réussite de demain.",
    theme: "Épargne & Prévenance"
  },
  {
    reference: "Proverbes 6:6-8",
    verseText: "« Va vers la fourmi, paresseux; considère ses voies, et deviens sage. Elle n'a ni chef, ni inspecteur, ni maître; elle prépare en été sa nourriture, elle amasse pendant la moisson de quoi manger. »",
    spiritualAdvice: "La fourmi n'attend pas la crise pour constituer des réserves. Même avec un petit budget étudiant, prends l'habitude de mettre de côté au moins 500 F ou 1 000 F chaque mois pour les imprévus académiques et de santé.",
    antiWasteTip: "Évite le gaspillage dans 'la papotte' : dose bien ton savon liquide et ta pâte dentifrice. Un tube bien géré peut durer 2 semaines de plus !",
    encouragement: "Que le Seigneur te donne la discipline de la fourmi pendant ces 9 mois académiques à Bondoukou !",
    theme: "Discipline & Prévoyance"
  },
  {
    reference: "Luc 14:28",
    verseText: "« Car, lequel de vous, s'il veut bâtir une tour, ne s'assied d'abord pour calculer la dépense et voir s'il a de quoi la achever ? »",
    spiritualAdvice: "Chaque début de mois ou d'année académique demande un temps d'arrêt. Planifier son budget sur STADJAI est une démarche de responsabilité spirituelle et morale pour honorer tes parents et ton Créateur.",
    antiWasteTip: "Calcule exactement tes trajets pour l'église ou la mosquée (1 000 F A/R). Regroupe tes sorties avec tes camarades de promotion pour optimiser le transport.",
    encouragement: "Tu n'es pas venu à l'Université de Bondoukou pour échouer, mais pour réussir avec méthode et prière.",
    theme: "Planification & Bâtisseur"
  },
  {
    reference: "Proverbes 13:11",
    verseText: "« La richesse acquise rapidement diminue, mais celui qui amasse peu à peu l'augmente. »",
    spiritualAdvice: "Ne cherche pas le luxe éphémère ou la compétition vestimentaire avec d'autres étudiants. La vraie richesse de l'étudiant réside dans la paix d'esprit, la santé et l'excellence dans ses études.",
    antiWasteTip: "À la boulangerie, fixe-toi un plafond quotidien strict (100 F à 200 F maximum pour le pain du matin). L'excès de friandises ruine les petits budgets.",
    encouragement: "Construis ton indépendance financière franc par franc, avec patience et foi.",
    theme: "Patience & Modération"
  },
  {
    reference: "Ecclésiaste 11:2",
    verseText: "« Donnes-en une part à sept et même à huit, car tu ne sais pas quel malheur peut arriver sur la terre. »",
    spiritualAdvice: "Diversifier et garder une marge de sécurité financière te protégera contre la maladie, les achats imprévus de fascicules ou les retards de transfert d'argent.",
    antiWasteTip: "Prévois toujours une souche de secours de tickets de cantine non consommés pour les jours de vaches maigres en fin de mois.",
    encouragement: "Reste prudent et vigilant dans tes choix quotidiens. Que la grâce de Dieu t'accompagne à l'Université de Bondoukou.",
    theme: "Prudence & Sécurité"
  },
  {
    reference: "Jean 6:12",
    verseText: "« Lorsqu'ils furent rassasiés, il dit à ses disciples : Ramassez les morceaux qui restent, afin que rien ne se perde. »",
    spiritualAdvice: "Après la multiplication des pains, Jésus a ordonné de ne rien gaspiller. Le gaspillage est un manque de respect envers le travail de ceux qui te soutiennent et la bénédiction divine.",
    antiWasteTip: "Ne laisse jamais tomber un ticket de cantine ou de la nourriture gâtée. Conserve bien tes aliments et collabore avec ton colocataire pour cuisiner à deux.",
    encouragement: "Honore chaque pièce de 100 F ou 500 F que tu reçois; Dieu multipliera ta sagesse !",
    theme: "Non-Gaspillage & Respect"
  }
];

export const BONDOUKOU_CAMPUS_TIPS = [
  {
    title: "Cantine CROU-B : Tickets & Souches",
    category: "Cantine",
    icon: "Utensils",
    text: "1 souche = 10 tickets. Matin : 1 ticket de 100 F (souche de 1 000 F). Midi & Soir : 1 ticket de 200 F (souche de 2 000 F). Pour 1 journée complète (matin + midi + soir), il te faut 3 tickets pour 500 F au total. Achète tes souches en début de mois !"
  },
  {
    title: "Vie Étudiante : Plats & Boulangerie",
    category: "Vie Étudiante",
    icon: "Soup",
    text: "À la Vie Étudiante, un plat chaud (Garba, plat de riz, maquis) commence à partir de 500 FCFA. À la boulangerie de la cité, il y a des pains à partir de 100 FCFA jusqu'à monter, avec des viennoiseries et gourmandises."
  },
  {
    title: "Stratégie 'La Papotte' (Hygiène & Entretien)",
    category: "Hygiène",
    icon: "Sparkles",
    text: "Le pack complet (savon de toilette, savon liquide lessive, pâte dentifrice, parfum) coûte au minimum 2 000 FCFA par mois. Achète les grands formats en début de semestre, ils reviennent beaucoup moins chers."
  },
  {
    title: "Transport École / Cours (500F Aller / 500F Retour)",
    category: "Transport École",
    icon: "Bus",
    text: "Pour aller en cours du lundi au vendredi (20 jours de cours par mois) : 500 FCFA aller + 500 FCFA retour = 1 000 FCFA par jour de cours (soit 20 000 FCFA par mois). Regroupe-toi avec tes camarades de classe pour le trajet !"
  },
  {
    title: "Optimisation du Transport Religieux (1 000 F / sortie)",
    category: "Transport",
    icon: "Bus",
    text: "Le transport pour aller à l'église ou la mosquée coûte 1 000 FCFA aller-retour par semaine (4 000 F par mois). Si ton budget est serré, vas-y à pied avec des camarades de promotion."
  }
];
